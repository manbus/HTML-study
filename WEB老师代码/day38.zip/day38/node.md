## HTML5
* 语义化的新标签
* 表单
* 多媒体
* canvas
* 新型选择器 classList  dataset 本地存储  地理定位  web Worker
