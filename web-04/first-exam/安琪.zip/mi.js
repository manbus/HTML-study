<script type="text/javascript">
$(".topbar-cart").hover(function(){
  $(".topbar-cart").css("color","#ff6700");
  $(".cart-xuangou").css("visibility","visible");
},function(){
  $(".topbar-cart").css("color","#b0b0b0");
  $(".cart-xuangou").css("visibility","hidden");
});
$(".search-input").focus(function(){
  $(".search-btn").css({
    "border":"1px solid #ff6700",
  });
  $(".search-input").css({
    "border":"1px solid #ff6700",
    "box-shadow":"none",
    "border-right":"none"
  });
  $(".hot-words").css("visibility","hidden");
  $(".search-words-box").css("visibility","visible");

});
$(".search-input").blur(function(){
  $(".search-btn").css({
    "border":"1px solid #e0e0e0",
  });
  $(".search-input").css({
    "border":"1px solid #e0e0e0",
    "box-shadow":"none",
    "border-right":"none"

  });
  $(".hot-words").css("visibility","visible");
  $(".search-words-box").css("visibility","hidden");
});

$(".head-nav ul li[name='xmsj']").hover(function(){
  $(".xmsj").css("visibility","visible");
},function(){
  $(".xmsj").css("visibility","hidden");
});
$(".head-nav ul li[name='hm']").hover(function(){
  $(".xmsj").css("visibility","visible");
},function(){
  $(".xmsj").css("visibility","hidden");
});
$(".head-nav ul li[name='pb']").hover(function(){
  $(".xmsj").css("visibility","visible");
},function(){
  $(".xmsj").css("visibility","hidden");
});
$(".head-nav ul li[name='ds']").hover(function(){
  $(".xmsj").css("visibility","visible");
},function(){
  $(".xmsj").css("visibility","hidden");
});
$(".head-nav ul li[name='hz']").hover(function(){
  $(".xmsj").css("visibility","visible");
},function(){
  $(".xmsj").css("visibility","hidden");
});
$(".head-nav ul li[name='lyq']").hover(function(){
  $(".xmsj").css("visibility","visible");
},function(){
  $(".xmsj").css("visibility","hidden");
});
$(".head-nav ul li[name='znyj']").hover(function(){
  $(".xmsj").css("visibility","visible");
},function(){
  $(".xmsj").css("visibility","hidden");
});
$(".head-nav ul li[name='fw']").hover(function(){
  $(".xmsj").css("visibility","visible");
},function(){
  $(".xmsj").css("visibility","hidden");
});
$(".head-nav ul li[name='sq']").hover(function(){
  $(".xmsj").css("visibility","visible");
},function(){
  $(".xmsj").css("visibility","hidden");
});

</script>
