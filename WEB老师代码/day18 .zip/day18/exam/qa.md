## link, @import 区别
*  @import是css3中
*  使用@import引入的样式表属于阻塞加载
*  link除了引入css之外，还有其他功能(icon,dns预解析)
