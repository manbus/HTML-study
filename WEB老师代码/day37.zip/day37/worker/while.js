while (true){
  console.log("我在干活，别催啦！");
}
